// 小红书小工具壳（普通脚本，容器 CSP 不允许内联脚本，所以单独放一个文件，必须在 game.js 之前加载）。
//
// 1. 报错收集：原来 index.html 里的内联脚本，挪到这里（RLP.errors 要读）。
// 2. 竖屏旋转：小工具容器永远是竖屏，拿不到陀螺仪、不能全屏、不能锁方向。手机竖着的时候把整个游戏顺时针转 90° 显示，
//    玩家把手机逆时针横过来拿（刘海在左）画面就是正的；窗口本身是横的就不转。
//    游戏代码里所有读屏幕坐标的地方（clientX / clientY、getBoundingClientRect）都照“没转过”的画面算，
//    所以这里把这两类读数换算成游戏横屏坐标，游戏源码一行不用改。
//
// 坐标约定：frame = 屏幕（竖屏）坐标，virtual = 游戏横屏坐标。顺时针转 90° 后 virtual(x, y) 在 frame 里是 (fw - y, x)，
// 反过来 frame(x, y) → virtual (y, fw - x)。
(function () {
  'use strict';

  window.__RLP_ERRORS = [];
  window.__RLP_CAPTURE = true;
  window.addEventListener('error', function (e) {
    window.__RLP_ERRORS.push({ type: 'error', message: String(e.message || (e.error && e.error.message) || e), stack: e.error && e.error.stack, source: e.filename, line: e.lineno });
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason;
    window.__RLP_ERRORS.push({ type: 'unhandledrejection', message: String((r && r.message) || r), stack: r && r.stack });
  });

  // 容器永远是竖屏、页面没法让它转：只要窗口是竖的就把画面转 90°，不管是不是手机（电脑上的小红书模拟器也是竖的）。
  // 网址加 ?rot=0 可以关掉（调试用）
  var canRot = new URLSearchParams(location.search).get('rot') !== '0';
  var box = document.getElementById('rot');
  var S = window.__RLP_ROT = { rot: false, fw: window.innerWidth, fh: window.innerHeight };

  function layout() {
    var fw = window.innerWidth, fh = window.innerHeight;
    S.fw = fw; S.fh = fh;
    S.rot = canRot && fh > fw;
    var vw = S.rot ? fh : fw, vh = S.rot ? fw : fh;
    box.style.width = vw + 'px';
    box.style.height = vh + 'px';
    box.style.setProperty('--rw', vw + 'px');
    box.style.setProperty('--rh', vh + 'px');
    box.style.transform = S.rot ? 'translateX(' + fw + 'px) rotate(90deg)' : 'none';
  }
  layout();
  window.addEventListener('resize', layout);
  window.addEventListener('orientationchange', layout);

  // 事件坐标：屏幕点 → 游戏横屏坐标
  function mapEventProto(proto) {
    if (!proto) return;
    var gx = Object.getOwnPropertyDescriptor(proto, 'clientX'), gy = Object.getOwnPropertyDescriptor(proto, 'clientY');
    if (!gx || !gx.get || !gy || !gy.get) return;
    var rx = gx.get, ry = gy.get;
    var virtX = function () { return ry.call(this); };
    var virtY = function () { return S.fw - rx.call(this); };
    [['clientX', virtX], ['clientY', virtY], ['pageX', virtX], ['pageY', virtY], ['x', virtX], ['y', virtY]].forEach(function (p) {
      var d = Object.getOwnPropertyDescriptor(proto, p[0]);
      if (!d || !d.get) return;
      var orig = d.get, fn = p[1];
      Object.defineProperty(proto, p[0], { configurable: true, enumerable: d.enumerable, get: function () { return S.rot ? fn.call(this) : orig.call(this); } });
    });
  }
  mapEventProto(window.MouseEvent && MouseEvent.prototype);
  mapEventProto(window.Touch && Touch.prototype);

  // 元素矩形：游戏里的元素在屏幕上是转过来的外接矩形，换算成游戏横屏坐标里的矩形
  var gbcr = Element.prototype.getBoundingClientRect;
  Element.prototype.getBoundingClientRect = function () {
    var r = gbcr.call(this);
    if (!S.rot || !box.contains(this)) return r;
    return new DOMRect(r.top, S.fw - r.right, r.height, r.width);
  };
})();
